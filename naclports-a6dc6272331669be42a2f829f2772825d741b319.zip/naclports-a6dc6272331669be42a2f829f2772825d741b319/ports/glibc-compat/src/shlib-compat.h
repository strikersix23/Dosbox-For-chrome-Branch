#define SHLIB_COMPAT(libc, introduced, obsoleted) 0
