/*
 * Copyright (c) 2012 The Native Client Authors. All rights reserved.
 * Use of this source code is governed by a BSD-style license that can be
 * found in the LICENSE file.
 */
#ifndef _GLIBCEMU_SYS_DIRENT_H
#define _GLIBCEMU_SYS_DIRENT_H

#include_next <sys/dirent.h>

#endif
