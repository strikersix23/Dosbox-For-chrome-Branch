#ifndef GLIBCEMU_MEMORY_H
#define GLIBCEMU_MEMORY_H       1

# include <string.h>

#endif

