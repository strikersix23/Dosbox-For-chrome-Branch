cd ../../scriptable/crypto
make
cp -v *.nexe ../../chrome_extensions/crypto_ext
